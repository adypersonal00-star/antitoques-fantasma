package com.zapia.antitoques

import android.accessibilityservice.AccessibilityService
import android.graphics.Color as AndroidColor
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.TextView
import java.util.ArrayDeque

class GhostTouchAccessibilityService:AccessibilityService(){
 private val handler=Handler(Looper.getMainLooper())
 private val eventTimes=ArrayDeque<Long>()
 private var overlay:FrameLayout?=null
 private var added=false
 private var lastTouch=0L
 private val expireOverlay: Runnable = Runnable{
  val now=System.currentTimeMillis()
  if(overlay!=null && now-lastTouch>=CALM_PERIOD_MS) removeOverlay() else handler.postDelayed(this.expireOverlay,CALM_PERIOD_MS-(now-lastTouch).coerceAtLeast(0L))
 }
 override fun onServiceConnected(){super.onServiceConnected();serviceInfo=serviceInfo.apply{eventTypes=AccessibilityEvent.TYPE_VIEW_CLICKED or AccessibilityEvent.TYPE_TOUCH_INTERACTION_START or AccessibilityEvent.TYPE_TOUCH_INTERACTION_END;notificationTimeout=35}
 }
 override fun onAccessibilityEvent(event:AccessibilityEvent?){
  if(event==null)return
  val now=System.currentTimeMillis()
  while(eventTimes.isNotEmpty() && now-eventTimes.first()>WINDOW_MS)eventTimes.removeFirst()
  when(event.eventType){
   AccessibilityEvent.TYPE_VIEW_CLICKED,AccessibilityEvent.TYPE_TOUCH_INTERACTION_START->eventTimes.addLast(now)
  }
  if(eventTimes.size>=TRIGGER_COUNT)showOverlay()
 }
 override fun onInterrupt(){}
 override fun onDestroy(){removeOverlay();handler.removeCallbacks(expireOverlay);super.onDestroy()}

 private fun showOverlay(){
  if(overlay!=null){noteTouch();return}
  val wm=getSystemService(WINDOW_SERVICE) as WindowManager
  val root=FrameLayout(this).apply{
   setBackgroundColor(AndroidColor.WHITE)
   isFocusable=true
   isFocusableInTouchMode=true
   val message=TextView(this@GhostTouchAccessibilityService).apply{
    text=""
    contentDescription="Pantalla protectora activa. Toca la pantalla; se quitará cuando pare la actividad."
    setTextColor(AndroidColor.BLACK)
    textSize=18f
    gravity=Gravity.CENTER
   }
   addView(message,FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,FrameLayout.LayoutParams.MATCH_PARENT))
   setOnTouchListener { _, _ -> noteTouch(); true }
  }
  val appOverlayAllowed = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)
  val overlayType = if (Build.VERSION.SDK_INT >= 26 && appOverlayAllowed) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
  val flags=WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
  val params=WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,overlayType,flags,PixelFormat.OPAQUE).apply{gravity=Gravity.TOP or Gravity.START;title="Antitoques Fantasma"}
  try{wm.addView(root,params);overlay=root;added=true;noteTouch()}catch(_:Exception){
   // If application overlay is blocked, the accessibility window type is the native fallback.
   if(overlayType!=WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY){
    try{params.type=WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;wm.addView(root,params);overlay=root;added=true;noteTouch()}catch(_:Exception){overlay=null;added=false}
   } else {overlay=null;added=false}
  }
 }
 private fun noteTouch(){lastTouch=System.currentTimeMillis();handler.removeCallbacks(expireOverlay);handler.postDelayed(expireOverlay,CALM_PERIOD_MS)}
 private fun removeOverlay(){val view=overlay;overlay=null;if(view!=null && added){try{(getSystemService(WINDOW_SERVICE) as WindowManager).removeView(view)}catch(_:Exception){}};added=false;eventTimes.clear()}
 companion object{
  private const val WINDOW_MS=1800L
  private const val CALM_PERIOD_MS=2500L
  private const val TRIGGER_COUNT=5
 }
}
