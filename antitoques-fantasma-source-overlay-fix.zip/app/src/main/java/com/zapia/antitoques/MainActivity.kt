package com.zapia.antitoques

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private val refreshCounter = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GhostSetup(this, refreshCounter.intValue) }
    }

    override fun onResume() {
        super.onResume()
        refreshCounter.intValue++
    }
}

@Composable
private fun GhostSetup(context: Context, refreshCounter: Int) {
    val enabled = isServiceEnabled(context)
    // TYPE_ACCESSIBILITY_OVERLAY is provided by the enabled accessibility service;
    // it does not require SYSTEM_ALERT_WINDOW or the separate "draw over apps" grant.
    @Suppress("UNUSED_VARIABLE")
    val refresh = refreshCounter

    val bg = Color(0xFF080A0D)
    val line = Color(0xFFEAF0F6)
    val mint = Color(0xFF9BFFB5)
    MaterialTheme(colorScheme = darkColorScheme(primary = mint, background = bg, surface = Color(0xFF141A20), onSurface = line)) {
        Column(
            Modifier.fillMaxSize().background(bg).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Text("ANTITOQUES FANTASMA", color = line, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Text("Servicio de emergencia", color = Color(0xFFFFCF7A), fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(
                "Si aparecen ráfagas rápidas de toques fantasma, el servicio intentará detectarlas mediante eventos de interacción táctil de Accesibilidad. Android no entrega todos los toques físicos de todas las pantallas o aplicaciones; por eso, puede no detectar algunos casos.",
                color = line, fontSize = 15.sp
            )
            Text(
                "Al detectar cinco inicios de interacción en 1,8 segundos, mostrará una pantalla completamente blanca, sin texto ni botón. Absorberá los toques y se cerrará sola tras 2,5 segundos sin actividad.",
                color = line, fontSize = 15.sp
            )
            Text(
                if (enabled) "Accesibilidad: activada" else "Accesibilidad: desactivada",
                color = if (enabled) mint else Color(0xFFFFC080),
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Button(
                onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
                modifier = Modifier.fillMaxWidth(),
                shape = RectangleShape
            ) { Text("Abrir ajustes de Accesibilidad") }
        }
    }
}

private fun isServiceEnabled(context: Context): Boolean {
    val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
    val name = ComponentName(context, GhostTouchAccessibilityService::class.java).flattenToString()
    return try {
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.split(':')?.any { it.equals(name, true) } == true && am.isEnabled
    } catch (_: Exception) {
        false
    }
}
