package com.zapia.antitoques

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import java.util.ArrayDeque

/**
 * Watches only the touch-interaction-start events Android exposes to accessibility services.
 * Android does not expose every physical tap on every app/surface to this service.
 */
class GhostTouchAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val touchStarts = ArrayDeque<Long>()
    private var overlay: View? = null
    private var lastOverlayTouch = 0L

    private val removeOverlayAfterQuiet = object : Runnable {
        override fun run() {
            val quietFor = SystemClock.uptimeMillis() - lastOverlayTouch
            if (overlay != null && quietFor >= CALM_PERIOD_MS) {
                removeOverlay()
            } else if (overlay != null) {
                handler.postDelayed(this, (CALM_PERIOD_MS - quietFor).coerceAtLeast(1L))
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            // Count actual accessibility touch-interaction events, not view-click notifications.
            eventTypes = AccessibilityEvent.TYPE_TOUCH_INTERACTION_START
            notificationTimeout = 0
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_TOUCH_INTERACTION_START) return
        if (overlay != null) return

        val now = SystemClock.uptimeMillis()
        while (touchStarts.isNotEmpty() && now - touchStarts.first() > TOUCH_WINDOW_MS) {
            touchStarts.removeFirst()
        }
        touchStarts.addLast(now)
        if (touchStarts.size >= TRIGGER_COUNT) showBlankOverlay()
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        handler.removeCallbacks(removeOverlayAfterQuiet)
        removeOverlay()
        super.onDestroy()
    }

    private fun showBlankOverlay() {
        if (overlay != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val whiteScreen = FrameLayout(this).apply {
            setBackgroundColor(Color.WHITE)
            isFocusable = true
            isFocusableInTouchMode = true
            // Absorb taps on the white screen and dismiss only after a quiet interval.
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_DOWN) noteOverlayTouch()
                true
            }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.OPAQUE
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            title = "Antitoques Fantasma"
        }

        try {
            wm.addView(whiteScreen, params)
            overlay = whiteScreen
            noteOverlayTouch()
        } catch (_: WindowManager.BadTokenException) {
            touchStarts.clear()
        } catch (_: SecurityException) {
            touchStarts.clear()
        }
    }

    private fun noteOverlayTouch() {
        lastOverlayTouch = SystemClock.uptimeMillis()
        handler.removeCallbacks(removeOverlayAfterQuiet)
        handler.postDelayed(removeOverlayAfterQuiet, CALM_PERIOD_MS)
    }

    private fun removeOverlay() {
        handler.removeCallbacks(removeOverlayAfterQuiet)
        val view = overlay
        overlay = null
        if (view != null) {
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(view)
            } catch (_: IllegalArgumentException) {
                // Already detached by Android during service shutdown.
            } catch (_: SecurityException) {
                // Service is shutting down; nothing else to clean up.
            }
        }
        touchStarts.clear()
    }

    companion object {
        private const val TOUCH_WINDOW_MS = 1_800L
        private const val CALM_PERIOD_MS = 2_500L
        private const val TRIGGER_COUNT = 5
    }
}
