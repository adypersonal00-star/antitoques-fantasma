package com.zapia.antitoques

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RectangleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent { GhostSetup(this) }}
 override fun onResume(){super.onResume()}
}

@Composable private fun GhostSetup(context:Context){
 var enabled by remember { mutableStateOf(isServiceEnabled(context)) }
 val bg=Color(0xFF080A0D);val line=Color(0xFFEAF0F6);val mint=Color(0xFF9BFFB5)
 MaterialTheme(colorScheme=darkColorScheme(primary=mint,background=bg,surface=Color(0xFF141A20),onSurface=line)){
  Column(Modifier.fillMaxSize().background(bg).padding(24.dp),verticalArrangement=Arrangement.spacedBy(18.dp)){
   Text("ANTITOQUES FANTASMA",color=line,fontSize=27.sp,fontWeight=FontWeight.Black)
   Text("Servicio de emergencia",color=Color(0xFFFFCF7A),fontSize=17.sp,fontWeight=FontWeight.Bold)
   Text("No se recomienda activarlo si el teléfono no tiene toques fantasma, o si solo ocurren de forma aislada o esporádica. Úsalo si aparecen ráfagas rápidas y seguidas de toques fantasma.",color=line,fontSize=15.sp)
   Text("Cuando detecte una ráfaga, mostrará una pantalla blanca que absorbe los toques. Se cerrará sola tras 2,5 segundos sin actividad.",color=line,fontSize=15.sp)
   Text(if(enabled)"Accesibilidad: activada" else "Accesibilidad: desactivada",color=if(enabled)mint else Color(0xFFFFC080),fontSize=15.sp,fontWeight=FontWeight.Bold)
   Button(onClick={context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))},modifier=Modifier.fillMaxWidth(),shape=RectangleShape){Text("Abrir ajustes de Accesibilidad")}
   OutlinedButton(onClick={enabled=isServiceEnabled(context)},modifier=Modifier.fillMaxWidth(),shape=RectangleShape){Text("Comprobar estado")}
   HorizontalDivider(color=line.copy(alpha=.35f))
   Text("Importante",color=mint,fontWeight=FontWeight.Bold)
   Text("Android no expone a una app normal todas las coordenadas de cada toque físico. La detección usa eventos que el sistema de Accesibilidad sí entrega; por eso no puede garantizar detectar cada toque fantasma en todas las apps o teléfonos.",color=Color(0xFFBAC4CD),fontSize=13.sp)
   Spacer(Modifier.height(6.dp))
   Text("Al aparecer la pantalla blanca, toca normalmente. Se quitará tras 2,5 segundos sin nuevos toques.",color=Color(0xFFBAC4CD),fontSize=13.sp)
  }
 }
}

private fun isServiceEnabled(context:Context):Boolean{
 val am=context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
 val name=ComponentName(context,GhostTouchAccessibilityService::class.java).flattenToString()
 return try{Settings.Secure.getString(context.contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.split(':')?.any{it.equals(name,true)}==true && am.isEnabled}catch(_:Exception){false}
}
